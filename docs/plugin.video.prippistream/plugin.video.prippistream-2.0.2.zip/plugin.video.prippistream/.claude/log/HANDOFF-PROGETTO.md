# PrippiStream — Handoff completo del progetto
*Scritto il 2026-07-14 e aggiornato il 2026-07-15 per chiunque riprenda il progetto da zero.*
*Le sezioni storiche restano per contesto; lo snapshot seguente è autoritativo.*

## SNAPSHOT AUTORITATIVO — 2026-07-15

**Stato verificato su disco:**
- repo pubblico `Desktop\PROGETTI\PrippiStream`: v1.5.7, HEAD/origin
  `89004cc`, codice intatto; presenti solo tool di test preesistenti untracked;
- workspace `Desktop\PROGETTI\PrippiStream-v2`: HEAD `e37eed1`
  (`Riconcilia v2 con la copia Kodi validata`), versione **1.9.950**; working
  tree con FASE 2 ARM/ricerca non ancora committata;
- zip 1.9.950 da 4.402.488 byte (SHA-256 `C3DB1D184281F0D8AC44B363AB7E77C5C6AA35F890A2499C7236309208EA8CE2`) in repo v2, `PrippiStream-TEST` e
  `PrippiStream-TEST\box`; server Range/206 su `172.20.10.2:8000` attivo al
  momento del salvataggio;
- nessun commit della FASE 2, nessun merge v2→v1, nessun push o deploy pubblico.

**Riconciliazione v2←AppData:** completata nel commit `e37eed1`; preservati fix
autoplay/lingua, diagnostica e Daddy SSL; importati skin/touch/popolamento,
oldlog ring e poster quantizzati. La vecchia sezione 3 è quindi storica.

**Esito BOX 1.9.949, log `(4)` del 2026-07-15:** home completa 2,873 s
(assemble 2,408 + paint 465 ms) contro 9,42 s in 1.9.948 e ~14,06 s in
1.9.947; RAM paint/post 821/827 MB contro 855/1064; righe mediana/p90/max
202/357/1108 ms contro 352/6988/29417. Profilo low-power, populate-on-focus,
cache persistente, trailer lazy e probe live differiti funzionano. Autoplay
The Office 1→2→3→4 e preferenze lingua/sottotitoli validati. Nessun crash,
OOM o errore apertura codec. Daddy arriva a Xameleon ma riceve HTTP 403;
prova altra rete differita. Cert error residui = `popcdn.day`, separati.

**Build 1.9.950 pronta, test BOX pendente:** debug generico default OFF;
migrazione una tantum spegne il valore legacy; `Invia Log` non lo riattiva.
Gli errori, traceback, warning, errori provider/HTTP/SSL, crash, `[PERF]` e
`[NET]` restano nei log. Cache risultati per provider/query: TTL 15 min,
cap 80, Item ricostruiti, metrica `[PERF] search.provider_cache`. Test locali
verdi: compileall, 27 XML, 140 JSON, unit cache, diff-check e audit zip.

**Prossimo passo esatto:** installare 1.9.950 sulla box copiando lo zip da
`test` a `kodiaddons`, installarlo da file locale e riavviare Kodi. Testare:
debug OFF, home, ricerca nuova e riuso cronologia, cancellazione cronologia,
4K OFF→ON→OFF, trailer, VOD/live e invio log; salvare come log `(5)`.
Dopo: analisi, eventuale 1.9.951 oppure freeze RC; test PC+box; RC senza
perf_log/logpush/TouchProbe; audit e merge selettivo v2→v1 con git-rm;
approvazione changelog; push solo su comando esplicito dell'utente.

**Roadmap dopo 2.0:** il documento “V3” è storico e va integrato nella stessa
v2→2.x. 2.1 = prestazioni residue misurate; 2.2 = firma/licenze/revoche;
2.3+ = `K_engine`, loader `.pye`, sorgente privata + feed pubblico separato.
La skin Kodi telefono è sospesa: mobile = APK nativo, con motore sincronizzato
da PrippiStream-v2.

---

## 0. ⭐ VOCABOLARIO DEI COMANDI — cosa intende l'utente quando dice… (LEGGERE PER PRIMO)

Queste parole hanno un significato PRECISO in questo progetto. Eseguire l'azione sbagliata
(es. pushare quando voleva solo un salvataggio) è un errore grave. **Nessuna di queste azioni
va fatta senza la frase esplicita dell'utente.** Le modifiche restano su disco finché non lo dice.

| L'utente dice… | Significa… | Cosa fare in pratica |
|---|---|---|
| **"salva" / "salva tutto" / "aggiorna la memoria"** | Snapshot IMMEDIATO dello stato della sessione nei file di **memoria** (NON è git, NON pubblica nulla). | Aggiornare i file memoria ESISTENTI pertinenti (v2-performance-project, pending-release-notes, + quelli del lavoro in corso) con: cosa fatto/validato, cosa resta, punto esatto di ripresa, path/build. Aggiornare le righe in `MEMORY.md`. Date assolute. **Verificare i fatti su disco** (git, versioni, zip) prima di scriverli — non fidarsi del solo ricordo della chat. NON creare file duplicati di "stato": lo stato vive nei file di progetto esistenti. Motivo: gli sono già sparite chat, la memoria è l'unica continuità. |
| **"fai build" / "buildami lo zip"** | Generare lo zip dell'addon (per lo più su **v2**). Non committa, non pubblica. | `py tools\make_addon_zip.py` nel repo giusto → zip in `docs\plugin.video.prippistream\`. Poi di solito si copia in `Desktop\PrippiStream-TEST\`. |
| **"fai deploy"** | Copiare i file cambiati nella **copia Kodi locale del PC** (`AppData\...\plugin.video.prippistream\`) per testare. **NON committa, NON pusha.** | Copiare ogni file modificato preservando i sottopercorsi + **svuotare i `__pycache__`** (varianti cpython-314 e cpython-38) dei .py toccati, così Kodi ricarica il bytecode. Tenere `addon.xml` locale ≥ versione pubblicata, o Kodi auto-aggiorna e sovrascrive. NB: "deploy sulla BOX" invece = la procedura zip-locale del §5. |
| **"fai push" / "rilascia" / "pubblica"** | Commit + `git push origin main` **su v1** → la GitHub Action builda e **pubblica lo ZIP a TUTTI gli utenti**. Azione seria e pubblica. | ⚠️ **Solo sul repo v1** (v2 non ha remote apposta). ⚠️ **GATE OBBLIGATORIO prima di pushare**: mostrare all'utente le note utente della sezione `## Prossima` di `changelog.txt` (il popup che vedranno gli utenti) **via lo strumento AskUserQuestion** per approvazione/modifica; solo dopo il sì si pusha. Poi: `git add` dei file specifici (MAI `git add -A` — eviti `.claude/` e segreti), commit **senza `[skip ci]`**, `git push origin main` (se rifiutato: `git pull --rebase origin main` poi ripushare — il remote ha spesso un commit bot `Release vX [skip ci]` avanti). Un "fai push" fa PRIMA il deploy locale, POI commit+push. |

**Regole trasversali:**
- **MAI combinare le azioni**: "fai deploy" NON pusha; "salva" NON committa né builda.
- **MAI push/deploy senza la frase esatta.** In dubbio, chiedere.
- **`release.ps1` in v2 NON va MAI eseguito** (fa commit+push su GitHub, righe 56-59): per buildare v2
  si usa SOLO `py tools\make_addon_zip.py`.
- Su questo PC: python = **`py`**; shell = **PowerShell 5.1** (niente `&&`; per i commit multi-riga usare
  `git commit -F file`).

---

## 1. Cos'è il progetto

**PrippiStream** è un addon video per Kodi con interfaccia stile Netflix (home a righe, hero,
Continua a guardare) che aggrega streaming italiano: StreamingCommunity (SC), CB01, AnimeUnity,
hd4me (Mega), Mediaset/Rai, canali live SKY/Sport/TV (ClearKey + DaddyLive), One Piece dedicato,
HentaiSaturn, download offline cifrato, ricerca globale multi-fonte con TMDB.

- **Utente/proprietario**: Michele Santeramo (git user `usandissm`), parla italiano, tester unico.
- La parola **"netflix" è BANDITA** dal codice e dalla UI (rename storico: netflixhome.py→prippihome.py,
  Netflix*→Prippi*). **Niente nomi di siti** visibili in UI. **Niente emoji/glifi** nelle stringhe UI
  (in Kodi diventano quadratini) — unica eccezione la stella ★ del rating.
- Memoria persistente delle sessioni Claude:
  `C:\Users\Michele Santeramo\.claude\projects\c--Users-Michele-Santeramo-Desktop-PROGETTI-PrippiStream\memory\`
  (indice in `MEMORY.md`, un file .md per argomento — lì c'è MOLTO più dettaglio di questo documento).

---

## 2. LE TRE COPIE DEL CODICE (leggere prima di toccare qualsiasi cosa)

Questo è il punto che ha causato tutti i guai recenti. Esistono TRE alberi di codice:

### a) Repo v1 — produzione (`C:\Users\Michele Santeramo\Desktop\PROGETTI\PrippiStream`)
- Git con remote GitHub. Branch `main`. **Serve gli utenti reali.**
- Versione live: **v1.5.7** (commit `89004cc Release v1.5.7 [skip ci]`).
- Release: si committa+pusha → una GitHub Action builda e pubblica (zip+addons.xml in `docs/`).
  I commit `Release vX [skip ci]` li fa la CI. Feed utenti = GitHub Pages su `docs/`.
- v1.5.7 contiene: fix buffering autoplay episodio-successivo (decoder Amlogic, `_await_player_teardown`)
  + fix lingua multi-episodio (`_lang_gen`) + setInfo 'video'. ⚠️ Rilasciati SENZA test su box reale.

### b) Workspace v2 — linea 2.0 (`C:\Users\Michele Santeramo\Desktop\PROGETTI\PrippiStream-v2`)
- Clone git **SENZA remote** (impossibile pushare per errore). Un commit per fase di lavoro.
- Qui vive il **progetto prestazioni** (fasi 0-10 tutte fatte e validate su PC: cache TMDB,
  adapter condiviso, snapshot home ~7× più veloce, WAL, cleanup, skin -1260 controlli, invoker caldo,
  nav-pause Tier-3…). Documento autoritativo: `ROADMAP_V2.md` nella root del repo.
- Versionamento dev: **1.9.9xx** (updater interno disabilitato; la 1.5.x pubblica non la sovrascrive mai;
  si aggiornerà alla 2.0.0 finale).
- **Build SOLO con `py tools\make_addon_zip.py`** (zip in `docs\plugin.video.prippistream\`).
  **MAI eseguire `release.ps1`** → fa commit+push su GitHub (righe 56-59)!
  Su questo PC python = `py` (launcher).
- HEAD attuale (2026-07-14): versione **1.9.947**, ultimi commit:
  - `956acca` fix canali daddy (fallback SSL `_urlopen_lax` — vedi §6)
  - `993f73b` port invio-log Telegram da v1.5.6 (era una REGRESSIONE) + esteso a tutti i log
  - `e0265cd`/`b8e55fa` diagnostica rete build 1.9.946 (netdiag, [NET], logpush incrementale)
  - `1454e31` build diagnostica 1.9.945 · `6b97c97` fix autoplay/lingua (port da v1.5.7)
- Working tree: pulito tranne l'artefatto zip 1.9.947 in `docs/` (non committato, irrilevante).

### c) Copia installata sul Kodi del PC (`C:\Users\Michele Santeramo\AppData\Roaming\Kodi\addons\plugin.video.prippistream`)
- Versione **1.9.944**. È la copia che l'utente USA e ha validato visivamente ("quella giusta").
- ⚠️ **CONTIENE EDIT MAI COMMITTATI** (round "touch telefono" 943/944 del 2026-07-08 sera:
  fix touch, populater righe veloce, ring kodi.old.log, ritocchi skin/loghi…).
- **NON è un repo git.** Tutto ciò che sta solo qui è invisibile alle build.

### ⚠️ LA REGOLA D'ORO (imparata a caro prezzo il 2026-07-13)
**Ogni modifica, ovunque venga fatta (v1, AppData), DEVE finire committata anche nel workspace v2**,
perché le build di test e la futura 2.0 nascono da lì. Il 13/07 l'utente ha trovato build box con
"Invia Log" rotto (v2 aveva ancora paste.rs) e regressioni grafiche: erano tutti edit rimasti solo
su v1/AppData. Quando una nota dice "applicato in entrambe le codebase", verificare COSA intende.

---

## 3. STORICO — Riconciliazione v2 ← AppData (COMPLETATA in `e37eed1`)

**Perché**: il workspace v2 è INDIETRO rispetto ad AppData (1.9.944). Ogni build da v2 mostra
regressioni rispetto a ciò che l'utente ha validato sul PC: loghi vecchi, riga SC `wraplist`
invece di `list`, altre differenze home. Finché non si riconcilia, ogni zip per la box è "sbagliato".

**Misura della divergenza** (fatta il 2026-07-13 con lo script `tree_diff.py`, vedi §8):
AppData(944) vs v2 — esclusi `__pycache__`, `.git`, `docs`, `tools`, `.pyc`, zip:

- **0 file solo in AppData** (niente da creare ex-novo).
- **~154 file SOLO in v2**: quasi tutti channels/servers/lib/guessit-test morti (il "cleanup
  alleggerimento" era stato fatto sulla copia installata e MAI git-rm-ato in v2) + alcuni file
  che invece VANNO TENUTI: `platformcode/netdiag.py` (nuovo, diagnostica), `platformcode/envtal.py`,
  `.gitignore`, `.gitattributes`, `release.ps1`, `resources/media/screenshot-*.png` (store, esclusi
  dallo zip comunque), `channels/mediasetplay.py.old` (spazzatura, eliminabile).
  → decidere caso per caso; la lista canali/servers morta va `git rm`-ata (il gotcha in memoria
  [[v2-cleanup-alleggerimento]] avverte: una copia additiva li resusciterebbe).
- **87 file DIVERSI**. I principali da portare AppData→v2:
  - `platformcode/prippihome.py` (**+361/−214** righe: AppData è più avanti — touch round, populater
    veloce, probabile origine del list-vs-wraplist… MA vedi TRAPPOLE sotto)
  - `resources/skins/Default/1080i/PrippiHome.xml` (+81/−38 — layout home, riga SC list/wraplist)
  - quasi TUTTI gli altri XML skin 1080i (DetailWindow, EpisodePicker, InfoWindow, NextDialog*,
    Recaptcha, Register, Renumber, ResumePlayback, SelectGroup, Servers, ShortCutMenu,
    TitleOrIDWindow, UpNextOverlay, ChannelSettings)
  - `service.py` (+41/−7) e `resources/settings.xml` (+31/−21)
  - `platformcode/config.py`, `platformcode/launcher.py`
  - **59 `resources/media/sport_posters/*.png`**: AppData = quantizzati palette (576 KB totali,
    i "loghi giusti"), v2 = RGB originali (1279 KB) → copiare quelli di AppData
  - `channels.json`: **v2 è PIÙ NUOVO** (domini aggiornati: streamingcommunityz.pl, tanti-film.study,
    il-geniodellostreaming.shop) → **NON sovrascrivere con AppData**
  - `addon.xml`: tenere la versione v2 (1.9.947→bump)

### ⚠️ TRAPPOLE — file dove v2 ha roba che AppData NON ha (NON sovrascrivere in blocco):
1. **`core/httptools.py`** — in v2 contiene la strumentazione [NET]/[PERF] per-richiesta
   (ttfb/byte/KB-s, `http.err` classificati, `net.block` Cloudflare, hook netdiag). AppData non ce l'ha.
   → fondere: prendere eventuali diff AppData e RIapplicare sopra la versione v2, non il contrario.
2. **`service.py`** — in v2 ha gli hook `logpush.start()` + `netdiag.start()` (gated su `perf_log`).
   AppData ha gli edit 943/944 (ring kodi.old.log ecc.). → fusione manuale.
3. **`platformcode/sportchannels.py`** — v2 ha il fix daddy `_urlopen_lax` (commit `956acca`).
   AppData NON ce l'ha (erano identici prima del fix). → NON toccare / non regredire.
4. **`platformcode/prippihome.py`** — v2 ha il fix autoplay/lingua (`6b97c97`: `_await_player_teardown`,
   `_lang_gen`) che AppData NON ha (verificato: 0 occorrenze in AppData). AppData ha il touch round
   che v2 non ha. → è LA fusione delicata. Metodo consigliato: partire dal file AppData e riapplicare
   sopra il diff `9a929ea..6b97c97 -- platformcode/prippihome.py` (entrambe le versioni derivano
   dalla 1.9.942 = commit `9a929ea`), oppure 3-way merge con git (branch temporaneo su `9a929ea`,
   commit del file AppData, merge su main).
5. **`specials/setting.py`** — v2 (993f73b) è PIÙ NUOVO di AppData (invio multi-log). Non regredire.
6. **`platformcode/logpush.py`** — v2 (incrementale+gzip) più nuovo di AppData. Non regredire.

### Dopo la riconciliazione
1. Commit dedicato in v2 (messaggio chiaro, in italiano come gli altri).
2. Bump `addon.xml` a **1.9.948**, build con `py tools\make_addon_zip.py`.
3. Copiare lo zip in `Desktop\PrippiStream-TEST\` e in `Desktop\PrippiStream-TEST\box\`.
4. Installare sulla box **col metodo locale** (§5 — MAI install-from-zip via rete).
5. Verificare sulla box: loghi giusti, riga SC list, canali daddy (fix `956acca`), e su PC che
   nulla sia regredito.

---

## 4. La box di test (vecchia Android box cinese)

**Hardware/ambiente**: Kodi 21.2 Omega, Android TV 10, ARMv8 1.34GHz, 2GB RAM, GUI 1280×720.
È il "caso peggiore" reale per il progetto prestazioni. **USB GUASTA** (nessuna pendrive letta).
NO adb (porta 5555 chiusa dal firmware). Rete = hotspot del telefono: box `172.20.10.11`,
PC `172.20.10.2` (possono cambiare! verificare con `ipconfig` e ping).

**Accesso da remoto**:
- **JSON-RPC porta 9090** (raw TCP) = API completa (Input.*, GUI.ActivateWindow, Addons.*,
  Player.*, Files.GetDirectory su sorgenti, XBMC.GetInfoLabels…). Client: `krpc.py` (vedi §8).
- **Webserver porta 8080** = API ridotta. Credenziali: utente `kodi`, password **`ciao1234`**
  (⚠️ non `prippi` come dicono note vecchie). Il suo `/vfs/` risponde **401 sui log comunque**
  (whitelist interna, le sorgenti non bastano) → NON è una via per scaricare i log.

**Sorgenti file create sulla box (restano configurate)**:
- `test` → `http://172.20.10.2:8000/` (il PC)
- `kodiaddons` → `special://home/addons/` (LA chiave di tutto: leggibile E scrivibile)
- `kodilogs` → `special://temp/` (lì stanno kodi.log e kodi.old.log)
- `reallogs` → `/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/temp/`

### 5. INSTALLARE UNA BUILD SULLA BOX (procedura COLLAUDATA — unica che funziona)
⚠️ **"Install from zip file" da sorgente di RETE fa crashare Kodi SEMPRE** (~10-20s dopo il clic,
anche con zip da 3,6 KB → non è dimensione/memoria: è l'installer che legge via HTTP). Vicolo cieco.

Procedura buona (sulla box attuale c'è la **1.9.947** installata così):
1. Sul PC: servire `Desktop\PrippiStream-TEST\box\` (metterci lo zip) con
   **`py Desktop\PrippiStream-TEST\serve_zip.py`** — scritto apposta: supporta **Range/206**,
   è **multi-thread** (ThreadingHTTPServer) e mette lo slash finale alle cartelle nel listing.
   ⚠️ `py -m http.server` NON va: ignora le Range e si blocca sulla prima connessione keep-alive.
2. Via JSON-RPC, nel File Manager di Kodi: pannello destro = `kodiaddons`, sinistro = `test`;
   evidenziare lo zip → menu contestuale → **Copy** → confermare → attendere che compaia
   in `special://home/addons/`.
3. Add-on browser → Install from zip file → **kodiaddons** → lo zip → si installa senza crash.
4. **Riavviare Kodi** (i service partono solo all'avvio; reuselanguageinvoker).
Script già pronti (vedi §8): `copy_zip_to_box.py`, `install_local_zip.py` (aggiornare il nome zip).

**Gotcha GUI-automation via JSON-RPC** (costati ore):
- File Manager: pannello sx = ctrl **20**, dx = ctrl **21**. Leggere la selezione con
  `Container(20|21).ListItem.Label` / `.NumItems` (le label `Container.FolderPath` e
  `ListItem.IsFolder` NON sono affidabili lì).
- Nei DIALOGHI usare `GUI.GetProperties → currentcontrol`; **MAI** `System.CurrentControl(Id)`
  (riporta la finestra sottostante → si preme il bottone sbagliato).
- Dialogo "Add source" (win 10129): fuoco iniziale variabile; risalire con Up finché il focus
  inizia con `[`; OK diventa focusabile solo con percorso+nome compilati; testo con
  `Input.SendText {'text':..., 'done':True}` sulla tastiera (win 10103).
- `[addons]` nel File Manager è una sorgente REMOTA dell'utente (thegroove360), NON la cartella
  addon di Kodi. Falso amico.
- Se serve non disturbare l'utente: controllare `Player.GetActivePlayers` prima di pilotare la GUI.

### Raccogliere i LOG dalla box
- **Il logpush/service NON consegna su questa box** (verificato: rete ok — il collector riceve i
  test — ma né il service di PrippiStream né un mini-addon service dedicato hanno mai spedito;
  causa ignota). Il mini-addon `script.prippilog` 1.0.0 è installato sulla box (innocuo).
- **La via che FUNZIONA: bottone "Invia Log allo Sviluppatore"** dentro PrippiStream
  (Impostazioni/Supporto). Dalla 1.9.947 manda **TUTTI** i log in un unico zip via Telegram
  (bot @PrippiStreamBot → arriva a Michele): kodi.log + kodi.old.log (+eventuali crashlog)
  + `info.txt` (versione, device, memoria). L'utente scarica lo zip e lo mette in
  `Desktop\PROGETTI\PrippiStream\.claude\log\` (lì ci sono già i log del 13/07).
- Dopo un CRASH il log utile è `kodi.old.log` (Kodi ruota al riavvio).
- Sul PC esistono anche `Desktop\PrippiStream-TEST\collector.py` (server :8199 per il logpush,
  gzip+offset) — inutile per questa box ma pronto per lo stick.

---

## 6. Risultati del test box del 2026-07-13 (i log sono in `.claude\log\`)

### a) 📊 Baseline ARM (l'obiettivo storico della FASE 0 — RAGGIUNTO)
La diagnostica `[NET]` ha risposto alla domanda "linea o codice?": **LINEA OK**
(download 500–1587 KB/s quasi sempre, tcp 60-264ms; un solo "MEDIOCRE" con dns 2,1s).
Quindi la lentezza della box è **CODICE/CPU**:
- `home.assemble (warm): 10180 ms` ← IL bersaglio della FASE 2
- `home.paint (warm): 3875 ms`
- `home.mem 1026MB al paint / 1113MB post-enrich` (su 1976MB totali, ~650-850 liberi al boot
  → pressione memoria concreta)
- TMDB in `ReadTimeout` (5s) ripetuti sotto carico
- hero 20-100ms (ok), righe 85-2900ms (outlier durante enrich)
→ Compilare la colonna BOX nelle tabelle [PERF] di `ROADMAP_V2.md` con questi numeri.

### b) 🐛 Canali daddy tutti offline = CA di sistema obsolete (FIX PRONTO, NON ancora sulla box)
Tutti i 23 canali `kind='daddy'` fallivano il probe con
`[SSL: CERTIFICATE_VERIFY_FAILED] unable to get local issuer certificate` su `phantemlis.top`,
mentre i 65 SKY (ClearKey/HLS via httptools+certifi impacchettato) funzionavano. Causa: le sonde
daddy usano `urllib.urlopen` = CA di SISTEMA, vecchie su Android 10.
**Fix committato in v2 `956acca`**: `_urlopen_lax` in `platformcode/sportchannels.py` — ritenta
con `ssl._create_unverified_context()` SOLO su quell'errore; applicato ai 4 urlopen del modulo.
Testato standalone con cert self-signed. **Incertezza onesta**: se la box è ANCHE dietro un blocco
IP dell'operatore (vedi memoria WINDTRE: il CDN phantemlis è intercettato sulle SIM WINDTRE),
il retry scaricherebbe la pagina 403 → il canale resterebbe correttamente offline. Da verificare
con la prossima build sulla box.

### c) Regressioni grafiche segnalate dall'utente = divergenza v2↔AppData (§3). Non bug singoli.

---

## 7. Diagnostica di test presente in v2 (build 1.9.945+) — DA REVERTARE prima della 2.0
- `perf_log` default **true** in `resources/settings.xml` (visibile in Supporto→Diagnostica)
- `platformcode/logpush.py` (invio kodi.log incrementale+gzip a `http://172.20.10.2:8199/log`)
- `platformcode/netdiag.py` (probe linea ogni 10min: tcp 1.1.1.1, dns themoviedb, download
  timeboxed da speed.cloudflare.com → riga `[NET] probe … => LINEA OK/LENTA/BLOCCATA`;
  riassunto traffico; riga `[SYS]` identikit device)
- hook di entrambi in `service.py` (gated su perf_log)
- strumentazione in `core/httptools.py` (righe `[PERF] http` con ttfb/KB-s, `http.err`, `net.block`)
Il grosso può restare in 2.0 se spento di default, ma la checklist "revert diagnostica" sta in
ROADMAP/memoria: minimo portare `perf_log` a false e togliere logpush.

---

## 8. Strumenti/scripts (dove stanno e cosa fanno)

**Durevoli, in `Desktop\PrippiStream-TEST\`:**
- `serve_zip.py` — server HTTP Range/206 multi-thread per passare file alla box (default: serve
  la sottocartella `box\`, porta 8000). SEMPRE questo, mai `http.server`.
- `collector.py` — ricevitore log :8199 (protocollo gzip+X-Log-Offset e legacy full-body);
  scrive `box_<nome>.log` + `box_perf.txt` (estrae [PERF]/[NET]/[SYS]/[DLaes]/ERROR).
- `src_prippilog\` + `box\script.prippilog-1.0.0.zip` — mini-addon service log-push (non consegna
  sulla box, tenuto per riferimento).
- gli zip delle build (1.9.930/942/945/946/947) come baseline A/B.

**Volatili (erano nello scratchpad della sessione 2026-07-13; se spariti, ricrearli — sono corti):**
- `krpc.py` — client JSON-RPC raw 9090: apre TCP, manda `{"jsonrpc":"2.0","method":...,"id":1}`,
  legge il primo oggetto JSON brace-bilanciato con id=1 (ignora le notifiche spontanee).
  Uso: `py krpc.py Metodo "{'param':valore}"` (+ `--host IP`).
- `fm2.py` — helper File Manager (panel 20/21, scan/select_item via Container(N).ListItem.Label).
- `copy_zip_to_box.py`, `install_local_zip.py` — copia+install build da locale (procedura §5).
- `add_source.py` — crea una sorgente file via GUI (usato per kodiaddons/kodilogs/reallogs).
- `tree_diff.py` — inventario divergenza AppData↔v2 (§3). RIESEGUIRLO prima della riconciliazione.
- `test_ssl_fallback.py`, `test_sendlog.py`, `test_netdiag.py`, `test_logpush_roundtrip.py` — test
  standalone dei fix (stub xbmc; utile riscriverli al bisogno).

---

## 9. Roadmap approvata (decisioni dell'utente, 2026-07-13)

Documento eseguibile: `C:\Users\Michele Santeramo\.claude\plans\v2-roadmap-implementazione.md`
(design esteso: `v3-fluidita-touch-sicurezza.md`). Decisioni chiave:
1. Tutto sulla **linea v2** → diventa 2.0 e cresce a 2.x (niente "V3" separato).
2. **PRESTAZIONI = priorità assoluta** (ora guidate dal baseline ARM §6a).
3. **Mobile → APK dedicato** (la skin-touch Kodi per telefono è SOSPESA; gli edit touch 943/944
   restano comunque da riconciliare perché contengono anche fix generali).
4. Bug download lenti su Kodi-mobile: parcheggiato (causa nota: `native_aes` non carica su Android
   Kodi → pyaes puro GIL-bound; nell'APK non esiste perché usa pycryptodome).
5. 2.0 esce come baseline validata PRIMA delle feature grosse (sicurezza/licenze = FASE 3).

**Ordine operativo da qui**:
① Riconciliazione v2←AppData (§3) → ② build 1.9.948 → box (§5) → verifica daddy+grafica
→ ③ colonna BOX in ROADMAP_V2.md → ④ FASE 2 perf (bersaglio: home.assemble 10s)
→ ⑤ stick Xiaomi quando disponibile → ⑥ revert diagnostica → merge in v1 → **release 2.0.0**.

---

## 10. Binario parallelo: APK Android nativo

Dir: `Desktop\PROGETTI\PrippiStreamApp` (git a sé, NO remote). Piano: `.claude\plans\apk-android-piano.md`.
- App nativa sideload che RIUSA il motore Python dell'addon via **Chaquopy** + UI **Compose** +
  player **Media3**. **MVP VALIDATO sul Samsung A16 dell'utente (2026-07-13)**: cerca su SC →
  apri serie → riproduci episodio, nativo e "velocissimo".
- Stack PINNATO (non cambiare): Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24 + compose-compiler 1.5.14,
  Chaquopy 16.0.0, Media3 1.4.1, minSdk 24, solo arm64-v8a.
- Fix chiave: i file-DATI (settings.xml, *.json) vanno spediti come **asset** e copiati in
  `filesDir/pydata` all'avvio (Chaquopy non fa leggere i data file con open()).
- Prossimi passi: home a righe, tutti i canali VOD, live ClearKey→Media3 DRM, download in
  background, `tools/sync_engine.py` (da scrivere) per risincronizzare il motore da PrippiStream-v2.
- Regola: il motore si modifica in PrippiStream-v2, POI si sincronizza nell'app.

---

## 11. Regole di lavoro e gotcha ricorrenti (sintesi — dettagli nei file memoria)

- **Port rule**: ogni fix v1/AppData → committare ANCHE in v2 (vedi §2). Audit pre-build:
  da v2 `git fetch <path v1> main` + `git log FETCH_HEAD --not HEAD` + verifica contenuti.
- **Settings live**: ogni nuova impostazione deve avere effetto SENZA riavvio. Su Kodi 21
  l'oggetto `xbmcaddon.Addon` cachato è STALE dopo openSettings → leggere sempre da
  un'istanza fresca (pattern `_read_live_settings` / `_apply_live_settings` in prippihome).
- **ISA + gzip**: mai lasciare `Accept-Encoding: gzip` negli header passati a inputstream.adaptive
  (manifest compresso = ISA muore).
- **Pipe-append**: mai appendere `|headers` a URL HLS/MPD in platformtools (guard `not mpd and not hls`).
- **TMDB e anime**: NON mettere tmdb_id negli infoLabels degli anime multi-parte (TMDB appiattisce
  il franchise); usare attributi laterali.
- **Kodi griglie**: addItems fa scroll-to-top → focus-park; `setFocus` su se stesso resetta a 0;
  bordi con `<ondown>` verso controllo non focusabile.
- **PowerShell 5.1**: niente `&&`; le virgolette doppie dentro stringhe passate a git si rompono →
  usare `git commit -F file`. Qui python = `py`.
- **Box lente + HTTPS**: fallback `ssl._create_unverified_context()` su CERTIFICATE_VERIFY_FAILED
  (pattern usato in invio-log Telegram e ora in sportchannels).
- **CB01/maxstream**: bloccato da Cloudflare a monte (non da noi); i fix captcha sono già dentro,
  ripartirà da solo alla rotazione dominio. Non perderci tempo.
- **WINDTRE/hotspot**: il CDN daddy (phantemlis) è intercettato dalle SIM WINDTRE ("Più Sicuri");
  nessun trucco lato addon aggira un blocco IP in-path → serve VPN. Non è un bug dell'addon.
- **Invio log**: bot Telegram, token offuscato base64-invertito in `specials/setting.py` (`_TG_TOKEN_OBF`).

---

## 12. Backlog aperto (oltre ai passi del §9)

- Test bottone "Invia Log" dal Kodi PC (su box già verificato de-facto: i log sono arrivati).
- Messaggio "Canale bloccato dall'operatore — usa una VPN" al posto del generico errore (opzionale).
- Pulizia impostazioni "Opzione 3" (rimozione codice morto motore — ALTO rischio, con calma).
- Prefill `Last_searched` mai funzionato (bug storico, bassa priorità, linea v1).
- Potatura periodica db.sqlite (~100MB) — item F7, parzialmente fatto (prune 30gg in 9c).
- Tester feedback backlog (anime 18+, ±10s player = skin Kodi non addon, salto-pagina…).
- `info.txt` dell'invio log mostra "PrippiStream 1.9.947 ??" — indagare i "??" (cosmetico).

---

## 13. File e percorsi utili in un colpo d'occhio

| Cosa | Dove |
|---|---|
| Repo v1 (produzione) | `Desktop\PROGETTI\PrippiStream` |
| Workspace v2 (2.0) | `Desktop\PROGETTI\PrippiStream-v2` (+ `ROADMAP_V2.md`) |
| Copia Kodi PC (riferimento UI) | `AppData\Roaming\Kodi\addons\plugin.video.prippistream` |
| Zip test + strumenti box | `Desktop\PrippiStream-TEST\` (`box\` = cartella servita) |
| Log box del 13/07 | `Desktop\PROGETTI\PrippiStream\.claude\log\` |
| Piani | `C:\Users\Michele Santeramo\.claude\plans\` (roadmap v2, v3-design, apk) |
| Memoria sessioni AI | `C:\Users\Michele Santeramo\.claude\projects\c--Users-Michele-Santeramo-Desktop-PROGETTI-PrippiStream\memory\` |
| App Android | `Desktop\PROGETTI\PrippiStreamApp` |

*Lo storico sopra resta utile, ma il prossimo passo indicato qui è superato
dall'addendum seguente.*

---

## Addendum 26 luglio 2026 — nuova direzione ufficiale

- Addon Kodi candidato: 1.9.973.
- La 1.9.972 ha reso la Home box decisamente più fluida.
- La 1.9.973 corregge starvation live con ordine TV → SKY → Sport e aggiunge un
  retry SC/VixCloud con token fresco prima dell'avvio A/V.
- L'utente ha approvato l'evoluzione dell'app Android esistente in un'unica app
  per telefono, tablet, Android TV, Google TV e box.
- Non creare un secondo package: conservare `com.prippi.stream`, firma, dati,
  download e updater.
- Primo gate TV: APK `armeabi-v7a` sulla box H313 ARM32, poi verticale
  Home → dettaglio → player interamente D-pad.
- Kodi resta fallback temporaneo.

Handoff autoritativo:

`C:\Users\Michele Santeramo\Desktop\PROGETTI\PrippiStreamApp\TV_APP_HANDOFF.md`

Memoria completa aggiornata: sezioni 26–28 di
`C:\Users\Michele Santeramo\Desktop\PROGETTI\PrippiStream\PRIPPISTREAM_MEMORIA_COMPLETA.md`.
